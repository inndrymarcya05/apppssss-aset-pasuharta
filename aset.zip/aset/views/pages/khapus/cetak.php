<style>
        /* CSS DARI ANDA */
        @media print {
            body * { visibility: hidden; }
            body, html { margin: 0; padding: 0; background-color: white !important; }
            .card, .card * { visibility: visible; }
            .card {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                margin: 0 !important;
                padding: 0 !important;
                border: none !important;
                box-shadow: none !important;
                max-width: none !important;
            }
            .no-print { display: none !important; }
        }
        
        /* Tambahan agar font terlihat rapi di layar */
        body { background-color: #f8f9fa; }
    </style>
</head>
<body>

<div class="container-fluid py-4">
    
    <div class="d-flex justify-content-between align-items-center mb-4 no-print">
        <a href="?pg=penghapusan&fl=list" class="btn btn-light border bg-white text-secondary shadow-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
        <button onclick="window.print()" class="btn btn-primary shadow-sm px-4">
            <i class="bi bi-printer-fill me-1"></i> Cetak BAST
        </button>
    </div>

    <div class="card border-0 shadow rounded-3 overflow-hidden mx-auto" style="max-width: 210mm; min-height: 297mm;"> 
        <div class="card-body p-5">
            
            <div class="border-bottom pb-4 mb-4 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <div class="bg-danger text-white rounded-3 d-flex align-items-center justify-content-center fw-bold fs-4" style="width: 60px; height: 60px;">
                        <i class="bi bi-trash3-fill"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold mb-0 text-dark">PT. MEN|SET</h5>
                        <p class="small text-muted mb-0">Jl.Bagus yabin 01 02 03</p>
                        <p class="small text-muted mb-0">Divisi Maintence</p>
                    </div>
                </div>
                <div class="text-end">
                    <h4 class="fw-bold text-uppercase mb-1" style="letter-spacing: 1px;">BAST Penghapusan</h4>
                    <span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-25 px-3 py-2 fs-6">
                        No: BAST/HPS/2024/001
                    </span>
                </div>
            </div>

            <div class="text-center mb-4">
                <h5 class="fw-bold text-uppercase text-decoration-underline mb-2">Berita Acara Penghapusan Aset</h5>
                <p class="text-muted small">
                    Dokumen ini adalah bukti sah penghapusan aset dari daftar inventaris perusahaan.
                </p>
            </div>

            <div class="alert alert-light border border-secondary border-opacity-25 d-flex justify-content-center gap-5 mb-4 py-3">
                <div class="text-center">
                    <small class="text-muted text-uppercase fw-bold" style="font-size: 0.7rem;">Tanggal Eksekusi</small>
                    <h6 class="fw-bold mb-0 text-primary">20 Februari 2024</h6>
                </div>
                <div class="border-start border-secondary border-opacity-25"></div>
                <div class="text-center">
                    <small class="text-muted text-uppercase fw-bold" style="font-size: 0.7rem;">Lokasi Penyimpanan</small>
                    <h6 class="fw-bold mb-0 text-dark">Gudang Limbah B3</h6>
                </div>
                <div class="border-start border-secondary border-opacity-25"></div>
                <div class="text-center">
                    <small class="text-muted text-uppercase fw-bold" style="font-size: 0.7rem;">Metode Penghapusan</small>
                    <h6 class="fw-bold mb-0 text-danger">Dimusnahkan / Dibuang</h6>
                </div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-6">
                    <div class="p-3 bg-light rounded-3 border border-light h-100">
                        <h6 class="fw-bold small text-uppercase text-primary mb-3 border-bottom pb-2">Penanggung Jawab Aset</h6>
                        <table class="table table-borderless table-sm mb-0 small">
                            <tr>
                                <td class="text-muted" width="80">Nama</td>
                                <td class="fw-bold text-dark">: Ahmad Jubaidi</td>
                            </tr>
                            <tr>
                                <td class="text-muted">NIP/NIK</td>
                                <td class="text-dark">: 19800101 20001</td>
                            </tr>
                            <tr>
                                <td class="text-muted">Jabatan</td>
                                <td class="text-dark">: Staff Inventory</td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="col-6">
                    <div class="p-3 bg-light rounded-3 border border-light h-100">
                        <h6 class="fw-bold small text-uppercase text-primary mb-3 border-bottom pb-2">Saksi / Mengetahui</h6>
                        <table class="table table-borderless table-sm mb-0 small">
                            <tr>
                                <td class="text-muted" width="80">Nama</td>
                                <td class="fw-bold text-dark">: Drs. H. Sulaiman</td>
                            </tr>
                            <tr>
                                <td class="text-muted">NIP/NIK</td>
                                <td class="text-dark">: 19750303 19991</td>
                            </tr>
                            <tr>
                                <td class="text-muted">Jabatan</td>
                                <td class="text-dark fw-bold">: Kepala Bagian Umum</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

            <p class="small text-muted mb-3">
                Berdasarkan hasil pemeriksaan, aset di bawah ini dinyatakan dihapus dengan rincian sebagai berikut:
            </p>

            <div class="table-responsive mb-4">
                <table class="table table-bordered align-middle border-secondary border-opacity-25">
                    <thead class="bg-light text-center">
                        <tr>
                            <th class="py-2 text-uppercase small fw-bold text-secondary" style="width: 5%;">No</th>
                            <th class="py-2 text-uppercase small fw-bold text-secondary">Kode Aset</th>
                            <th class="py-2 text-uppercase small fw-bold text-secondary" style="width: 35%;">Nama Barang</th>
                            <th class="py-2 text-uppercase small fw-bold text-secondary">Kondisi</th>
                            <th class="py-2 text-uppercase small fw-bold text-secondary">Nilai Buku</th>
                            <th class="py-2 text-uppercase small fw-bold text-secondary">Alasan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="text-center small">1</td>
                            <td class="text-center"><span class="small fw-bold font-monospace">AST-2021-098</span></td>
                            <td>
                                <span class="fw-bold d-block text-dark">Laptop Lenovo Thinkpad</span>
                                <span class="small text-muted">SN: 8829-KKJ-091</span>
                            </td>
                            <td class="text-center"><span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-10 rounded-pill px-2">Rusak Berat</span></td>
                            <td class="text-end small">Rp 0,-</td>
                            <td class="small text-muted">Mati total (Kena Air)</td>
                        </tr>
                        <tr>
                            <td class="text-center small">2</td>
                            <td class="text-center"><span class="small fw-bold font-monospace">AST-2019-112</span></td>
                            <td>
                                <span class="fw-bold d-block text-dark">Printer Epson L3110</span>
                                <span class="small text-muted">SN: EPS-221-002</span>
                            </td>
                            <td class="text-center"><span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-10 rounded-pill px-2">Rusak Berat</span></td>
                            <td class="text-end small">Rp 150.000,-</td>
                            <td class="small text-muted">Head Buntu Permanen</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="mb-5 p-3 bg-light border border-secondary border-opacity-10 rounded-3">
                <h6 class="fw-bold small text-uppercase mb-2">Pernyataan Penghapusan:</h6>
                <ol class="small text-muted text-justify mb-0 ps-3" style="line-height: 1.6;">
                    <li>Barang-barang tersebut di atas telah diperiksa secara fisik dan dinyatakan tidak lagi memiliki nilai ekonomis atau fungsi pakai bagi perusahaan.</li>
                    <li>Dengan ditandatanganinya berita acara ini, maka status aset tersebut resmi <strong>dihapus</strong> dari Buku Inventaris Perusahaan.</li>
                    <li>Segala bentuk fisik aset akan diproses (dimusnahkan/dilelang/dihibahkan) sesuai dengan peraturan yang berlaku.</li>
                </ol>
            </div>

            <div class="row mt-5 pt-4">
                <div class="col-6 text-center">
                    <p class="small text-muted mb-1">Jakarta, 20 Februari 2024</p>
                    <p class="fw-bold small">Dibuat Oleh (Admin),</p>
                    <br><br><br>
                    <p class="fw-bold text-decoration-underline mb-0">Ahmad Jubaidi</p>
                    <p class="small text-muted">Staff Inventory</p>
                </div>
                <div class="col-6 text-center">
                    <p class="small text-muted mb-1">Mengetahui & Menyetujui,</p>
                    <p class="fw-bold small">Kepala Bagian Umum,</p>
                    <br><br><br>
                    <p class="fw-bold text-decoration-underline mb-0">Drs. H. Sulaiman</p>
                    <p class="small text-muted">NIP. 19750303 19991</p>
                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>