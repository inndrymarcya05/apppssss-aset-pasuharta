<div class="card border-0 shadow-sm rounded-3 overflow-hidden">
    
    <div class="p-4 border-bottom d-flex flex-wrap gap-3 justify-content-between align-items-center bg-white">
        <div>
            <div class="d-flex align-items-center gap-2">
                <h6 class="fw-bold mb-0">Edit BAST Penghapusan</h6>
                <span class="badge bg-warning bg-opacity-10 text-warning border border-warning border-opacity-10 rounded-pill px-2">Draft</span>
            </div>
            <small class="text-muted">Perbarui data dokumen atau rincian aset</small>
        </div>
        <div class="d-flex gap-2">
            <a href="?pg=penghapusan&fl=list" class="btn btn-light btn-sm border text-secondary">
                <i class="bi bi-arrow-left"></i> Batal
            </a>
            <a href="?pg=penghapusan&fl=list" class="btn btn-primary btn-sm d-flex align-items-center gap-2">
                <i class="bi bi-check-lg"></i> Simpan Perubahan
            </a>
        </div>
    </div>

    <div class="card-body p-0">
        
        <div class="p-4 bg-white">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="small fw-bold text-secondary mb-1">No. Dokumen</label>
                    <input type="text" class="form-control form-control-sm border bg-light text-dark fw-bold shadow-none" value="BAST/HPS/2024/001" readonly>
                </div>
                
                <div class="col-md-3">
                    <label class="small fw-bold text-secondary mb-1">Tanggal Penghapusan</label>
                    <input type="date" class="form-control form-control-sm border shadow-none" value="2024-02-20">
                </div>

                <div class="col-md-3">
                    <label class="small fw-bold text-secondary mb-1">Status Dokumen</label>
                    <select class="form-select form-select-sm border shadow-none">
                        <option value="draft" selected>Draft (Masih diedit)</option>
                        <option value="final">Final (Disetujui)</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="small fw-bold text-secondary mb-1">Penanggung Jawab</label>
                    <input type="text" class="form-control form-control-sm border shadow-none" value="Budi Santoso (Kabag Logistik)">
                </div>

                <div class="col-12">
                    <label class="small fw-bold text-secondary mb-1">Keterangan / Alasan Penghapusan</label>
                    <textarea class="form-control form-control-sm border shadow-none" rows="2">Penghapusan aset elektronik yang rusak akibat banjir gudang bulan Januari. Barang sudah tidak bisa diperbaiki (Total Loss).</textarea>
                </div>
            </div>
        </div>

        <div class="bg-light border-top border-bottom py-2 px-4 d-flex justify-content-between align-items-center">
            <span class="fw-bold small text-secondary text-uppercase">Rincian Aset (3 Item)</span>
            
            <a href="" class="btn btn-primary btn-sm bg-primary bg-opacity-10 text-primary border-0 fw-bold" data-bs-toggle="modal" data-bs-target="#modalPilihAset">
                <i class="bi bi-plus-circle me-1"></i> Tambah Barang
            </a>
        </div>

        <div class="table-responsive">
            <table class="table table-premium mb-0 align-middle table-hover">
                <thead class="bg-light">
                    <tr>
                        <th class="ps-4 py-3 text-uppercase small fw-bold text-secondary">Kode Aset</th>
                        <th class="py-3 text-uppercase small fw-bold text-secondary">Nama Aset</th>
                        <th class="py-3 text-uppercase small fw-bold text-secondary">Kondisi</th>
                        <th class="py-3 text-uppercase small fw-bold text-secondary">Lokasi Asal</th>
                        <th class="text-center pe-4 py-3 text-uppercase small fw-bold text-secondary">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="ps-4"> 
                            <span class="fw-bold small text-dark">AST-2021-098</span>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="bg-danger bg-opacity-10 text-danger rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width:32px; height:32px;">
                                    <i class="bi bi-laptop"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <span class="fw-bold text-dark fs-6">Laptop Lenovo Thinkpad</span>
                                    <span class="small text-muted">Elektronik</span>
                                </div>
                            </div>
                        </td>
                        <td><span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-10 rounded-pill px-3">Rusak Berat</span></td>
                        <td class="text-secondary small">Gudang Lt. 1</td>
                        <td class="text-end pe-4">
                            <a href="#" class="btn btn-sm text-danger bg-danger bg-opacity-10 border-0 rounded-2" style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center;" onclick="return confirm('Hapus item ini dari BAST?')">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>

                    <tr>
                        <td class="ps-4"> 
                            <span class="fw-bold small text-dark">AST-2019-112</span>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="bg-warning bg-opacity-10 text-warning rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width:32px; height:32px;">
                                    <i class="bi bi-printer"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <span class="fw-bold text-dark fs-6">Printer Epson L3110</span>
                                    <span class="small text-muted">Elektronik</span>
                                </div>
                            </div>
                        </td>
                        <td><span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-10 rounded-pill px-3">Rusak Berat</span></td>
                        <td class="text-secondary small">R. Tata Usaha</td>
                        <td class="text-end pe-4">
                            <a href="#" class="btn btn-sm text-danger bg-danger bg-opacity-10 border-0 rounded-2" style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center;">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>

                     <tr>
                        <td class="ps-4"> 
                            <span class="fw-bold small text-dark">AST-2020-005</span>
                        </td>
                        <td>
                            <div class="d-flex align-items-center gap-2">
                                <div class="bg-primary bg-opacity-10 text-primary rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width:32px; height:32px;">
                                    <i class="bi bi-display"></i>
                                </div>
                                <div class="d-flex flex-column">
                                    <span class="fw-bold text-dark fs-6">Monitor LG 24 Inch</span>
                                    <span class="small text-muted">Elektronik</span>
                                </div>
                            </div>
                        </td>
                        <td><span class="badge bg-danger bg-opacity-10 text-danger border border-danger border-opacity-10 rounded-pill px-3">Rusak Berat</span></td>
                        <td class="text-secondary small">Gudang Lt. 1</td>
                        <td class="text-end pe-4">
                            <a href="#" class="btn btn-sm text-danger bg-danger bg-opacity-10 border-0 rounded-2" style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center;">
                                <i class="bi bi-trash"></i>
                            </a>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>