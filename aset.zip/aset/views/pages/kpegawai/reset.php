<div class="card-premium p-0 overflow-hidden shadow-sm col-lg-10 mx-auto">
    <div class="p-4 border-bottom d-flex flex-wrap gap-3 justify-content-between align-items-center bg-white">
        <h6 class="fw-bold mb-0">Data Pegawai</h6>
        <a href="?pg=kpegawai&fl=list" class="btn btn-primary text-light btn-sm px-4 fw-bold shadow-sm"></i>
        Keluar</a>
    </div>
    
    <div class="p-4">
        <form method="post" class="row g-3">
            
            <div class="col-md-12">
                <label class="form-label small fw-bold text-secondary">Password Baru</label>
                <input type="password" class="form-control" placeholder="Password Baru" name="password" value="" required>
            </div>

           <div class="p-3 border-top d-flex justify-content-end gap-2 bg-light">
                <a href="?pg=kpegawai&fl=list" class="btn btn-warning border bg-warning text-light btn-sm px-4 fw-bold">Reset</a>
                <button type="submit" class="btn btn-primary btn-sm px-4 fw-bold shadow-sm"><i class="bi bi-save me-1"></i> Simpan Pegawai </button>
                </div>
             </form>
        </div>
    </div>
</div>