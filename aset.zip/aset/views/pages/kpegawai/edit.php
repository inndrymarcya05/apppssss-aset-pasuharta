


<div class="card-premium p-0 overflow-hidden shadow-sm col-lg-10 mx-auto">
    <div class="p-4 border-bottom d-flex flex-wrap gap-3 justify-content-between align-items-center bg-white">
        <h6 class="fw-bold mb-0">Data Pegawai</h6>
        <a href="?pg=kpegawai&fl=list" class="btn btn-primary text-light btn-sm px-4 fw-bold shadow-sm"></i>
        Keluar</a>
    </div>
    
    <div class="p-4">
        <form method="post" class="row g-3">
            
            <div class="col-md-6">
                <label class="form-label small fw-bold text-secondary">Nama Lengkap</label>
                <input type="text" class="form-control" placeholder="Nama Lengkap" name="user" value="" required>
            </div>

            <div class="col-md-6">
                <label class="form-label small fw-bold text-secondary">Username</label>
                <input type="text" class="form-control" placeholder="Username Login" name="username" value="" required>
            </div>
            
            <div class="col-md-4">
                <label class="form-label small fw-bold text-secondary">Status</label>
                <select class="form-select" name="status">
                    <option value="Aktif">Aktif</option>
                    <option value="Non-Aktif">Non-Aktif</option>
                    <option value="Cuti">Cuti</option>
                </select>
            </div>

            <div class="col-md-4">
                <label class="form-label small fw-bold text-secondary">Gender</label>
                <select class="form-select" name="gender">
                    <option value="Laki-laki">Laki-laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>

            <div class="col-md-4">
                <label class="form-label small fw-bold text-secondary">Role</label>
                <select class="form-select" name="role">
                    <option value="Admin">AdminKelola</option>
                    <option value="Admin">AdminInstansi</option>
                    <option value="User">Staf</option>
                    <option value="Editor">Teknisi</option>
                </select>
            </div>
        
            <div class="col-12">
                <hr class="my-3 text-secondary opacity-25">
            </div>
        
            <div class="p-3 border-top d-flex justify-content-end gap-2 bg-light">
                <a href="?pg=kpegawai&fl=list" class="btn btn-light border bg-white text-secondary btn-sm px-4 fw-bold">Batal</a>
                <button type="submit" class="btn btn-primary btn-sm px-4 fw-bold shadow-sm"><i class="bi bi-save me-1"></i> Simpan Pegawai </button>
                </div>
             </form>
        </div>
    </div>