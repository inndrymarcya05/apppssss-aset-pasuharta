<?php

    $pg=$_GET['pg'];
    $fl=$_GET['fl'];
    if($pg=='kpegawai' && $fl=='hapus'){
        header('Location:index.php?');
        
    }

?>