    <?php include('beranda/judul.php') ?>

    <?php include('beranda/transaksi.php') ?>