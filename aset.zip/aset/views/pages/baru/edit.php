<div class="card border-0 shadow-sm rounded-3 overflow-hidden">
    
    <div class="p-4 border-bottom bg-white d-flex justify-content-between align-items-center">
        <div>
            <h6 class="fw-bold mb-0">Update Maintenance</h6>
            <small class="text-muted">Perbarui status pengerjaan dan realisasi biaya.</small>
        </div>
        <span class="badge bg-warning text-dark border border-warning border-opacity-25 px-3">
            Status: Dalam Proses
        </span>
    </div>

    <div class="card-body p-4">
        <form action="" method="POST">
            
            <div class="row g-4">
                <div class="col-md-5">
                    <div class="p-4 bg-light rounded-3 border border-light h-100">
                        <h6 class="fw-bold small text-muted text-uppercase mb-3 border-bottom pb-2">Detail Permintaan Awal</h6>
                        
                        <div class="mb-3">
                            <label class="small text-secondary d-block">Aset</label>
                            <span class="fw-bold text-dark">Laptop Dell XPS (DL-IT-099)</span>
                        </div>
                        <div class="mb-3">
                            <label class="small text-secondary d-block">Vendor / Bengkel</label>
                            <span class="fw-bold text-dark">CV. Komputer Jaya</span>
                        </div>
                        <div class="mb-3">
                            <label class="small text-secondary d-block">Keluhan Awal</label>
                            <p class="small text-muted bg-white p-2 rounded border mb-0">
                                "Layar berkedip dan kadang mati sendiri saat charger dilepas."
                            </p>
                        </div>
                        <div class="mb-0">
                            <label class="small text-secondary d-block">Estimasi Biaya</label>
                            <span class="fw-bold text-dark">Rp 1.500.000</span>
                        </div>
                    </div>
                </div>

                <div class="col-md-7">
                    <div class="h-100 d-flex flex-column justify-content-center">
                        <label class="form-label small fw-bold text-primary text-uppercase mb-3">Form Penyelesaian</label>

                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label small fw-bold text-secondary">Update Status</label>
                                <select class="form-select shadow-none border-primary border-opacity-25 bg-primary bg-opacity-10 text-primary fw-bold">
                                    <option value="Proses">Sedang Dikerjakan</option>
                                    <option value="Selesai" selected>Selesai / Diambil</option>
                                    <option value="Batal">Dibatalkan</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label small fw-bold text-secondary">Tanggal Selesai</label>
                                <input type="date" class="form-control shadow-none border" value="<?php echo date('Y-m-d'); ?>">
                            </div>
                            
                            <div class="col-12">
                                <label class="form-label small fw-bold text-secondary">Realisasi Biaya (Final)</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-white text-dark fw-bold border-end-0">Rp</span>
                                    <input type="number" class="form-control shadow-none border-start-0 fw-bold" value="1500000">
                                </div>
                                <div class="form-text small text-muted">Isi sesuai nota/kwitansi akhir.</div>
                            </div>

                            <div class="col-12">
                                <label class="form-label small fw-bold text-secondary">Catatan Hasil Pengerjaan</label>
                                <textarea class="form-control shadow-none" rows="3" placeholder="Contoh: LCD diganti baru, garansi sparepart 1 bulan..."></textarea>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="d-flex justify-content-end gap-2 pt-4 mt-4 border-top">
                <a href="?pg=baru&fl=list" class="btn btn-light border bg-white text-secondary btn-sm px-4 fw-bold">Kembali</a>
                <a href="?pg=baru&fl=edit" class="btn btn-success btn-sm px-4 fw-bold shadow-sm">
                    <i class="bi bi-check-circle me-1"></i> Simpan & Selesaikan
                </a>
            </div>
        </form>
    </div>
</div>