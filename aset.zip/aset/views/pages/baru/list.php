<div class="card border-0 shadow-sm rounded-3 overflow-hidden">
    
    <div class="p-4 border-bottom d-flex flex-wrap gap-3 justify-content-between align-items-center bg-white">
        <div>
            <h6 class="fw-bold mb-0">Riwayat Maintenance & Perbaikan</h6>
            <small class="text-muted">Kelola jadwal service, perbaikan kerusakan, dan perpanjangan.</small>
        </div>
        <div class="d-flex gap-2">
            <div class="input-group input-group-sm border rounded-2 overflow-hidden" style="width: 250px;">
                <span class="input-group-text bg-white border-0 text-muted"><i class="bi bi-search"></i></span>
                <input type="text" class="form-control border-0 shadow-none" placeholder="Cari Aset / Vendor...">
            </div>
            <a href="?pg=baru&fl=tambah" class="btn btn-primary btn-sm">
                <i class="bi bi-wrench-adjustable me-1"></i> Input Maintenance
            </a>
        </div>
    </div>

    <div class="table-responsive">
        <table class="table table-premium mb-0 align-middle table-hover">
            <thead class="bg-light">
                <tr>
                    <th class="ps-4 py-3 text-uppercase small fw-bold text-secondary">ID MT</th>
                    <th class="py-3 text-uppercase small fw-bold text-secondary">Aset</th>
                    <th class="py-3 text-uppercase small fw-bold text-secondary">Jenis & Vendor</th>
                    <th class="py-3 text-uppercase small fw-bold text-secondary">Tanggal</th>
                    <th class="py-3 text-uppercase small fw-bold text-secondary text-end">Biaya</th>
                    <th class="py-3 text-uppercase small fw-bold text-secondary text-center">Status</th>
                    <th class="text-center pe-4 py-3 text-uppercase small fw-bold text-secondary">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="ps-4"><span class="fw-bold small text-dark">MT-001</span></td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <div class="bg-light border text-secondary rounded-2 d-flex align-items-center justify-content-center fw-bold small" style="width:36px; height:36px;">
                                <i class="bi bi-laptop"></i>
                            </div>
                            <div>
                                <span class="fw-bold text-dark d-block" style="font-size: 0.9rem;">Laptop Dell XPS</span>
                                <span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary border-opacity-10 rounded-pill" style="font-size: 0.65rem;">DL-IT-099</span>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="fw-bold text-dark d-block" style="font-size: 0.9rem;">Perbaikan Layar</span>
                        <span class="text-muted small"><i class="bi bi-shop me-1"></i> CV. Komputer Jaya</span>
                    </td>
                    <td class="small text-secondary">
                        <i class="bi bi-calendar-event me-1"></i> 15 Okt 2023
                    </td>
                    <td class="text-end fw-bold text-dark">Rp 1.500.000</td>
                    <td class="text-center">
                        <span class="badge bg-warning text-dark border border-warning border-opacity-25 rounded-pill px-3">
                            <i class="bi bi-gear-wide-connected me-1"></i> Proses
                        </span>
                    </td>
                    <td class="text-end pe-4">
                        <div class="d-flex justify-content-end gap-2">
                            <a href="?pg=baru&fl=edit" class="btn btn-sm text-primary bg-primary bg-opacity-10 border-0 rounded-2" style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center;" title="Update Progres">
                                <i class="bi bi-pencil-square"></i>
                            </a>
                            
                            <button type="button" 
                                    class="btn btn-sm text-danger bg-danger bg-opacity-10 border-0 rounded-2" 
                                    style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center;"
                                    data-bs-toggle="modal" 
                                    data-bs-target="#modalHapus" 
                                    data-id="MT-001">
                                <i class="bi bi-trash"></i>
                            </button>
                            </div>
                    </td>
                </tr>

                <tr class="bg-light bg-opacity-50">
                    <td class="ps-4"><span class="fw-bold small text-muted">MT-002</span></td>
                    <td>
                        <div class="d-flex align-items-center gap-2">
                            <div class="bg-light border text-secondary rounded-2 d-flex align-items-center justify-content-center fw-bold small" style="width:36px; height:36px;">
                                <i class="bi bi-car-front"></i>
                            </div>
                            <div>
                                <span class="fw-bold text-muted d-block" style="font-size: 0.9rem;">Toyota Avanza</span>
                                <span class="badge bg-secondary bg-opacity-10 text-secondary border border-secondary border-opacity-10 rounded-pill" style="font-size: 0.65rem;">B 1234 CD</span>
                            </div>
                        </div>
                    </td>
                    <td>
                        <span class="fw-bold text-muted d-block" style="font-size: 0.9rem;">Ganti Oli & Service</span>
                        <span class="text-muted small"><i class="bi bi-shop me-1"></i> Bengkel Resmi</span>
                    </td>
                    <td class="small text-muted">
                        <i class="bi bi-check-all me-1"></i> 10 Okt 2023
                    </td>
                    <td class="text-end fw-bold text-muted">Rp 850.000</td>
                    <td class="text-center">
                        <span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-10 rounded-pill px-3">
                            <i class="bi bi-check-circle-fill me-1"></i> Selesai
                        </span>
                    </td>
                    <td class="text-end pe-4">
                        <div class="d-flex justify-content-end gap-2">
                            <a href="#" class="btn btn-sm text-secondary bg-secondary bg-opacity-10 border-0 rounded-2" style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center;" title="Lihat Detail"><i class="bi bi-eye"></i></a>
                            
                            <button type="button" 
                                    class="btn btn-sm text-danger bg-danger bg-opacity-10 border-0 rounded-2" 
                                    style="width: 32px; height: 32px; display: inline-flex; align-items: center; justify-content: center;"
                                    data-bs-toggle="modal" 
                                    data-bs-target="#modalHapus" 
                                    data-id="MT-002">
                                <i class="bi bi-trash"></i>
                            </button>
                            </div>
                    </td>
                </tr>
            </tbody>
        </table>
    </div>
    
    <div class="p-3 border-top d-flex justify-content-between align-items-center bg-white">
        <span class="text-muted small ms-2">Menampilkan 2 Data</span>
        <nav>
            <ul class="pagination pagination-sm mb-0">
                <li class="page-item disabled"><a class="page-link border-0 bg-transparent" href="#">Prev</a></li>
                <li class="page-item active"><a class="page-link border rounded-2" href="#">1</a></li>
                <li class="page-item"><a class="page-link border-0 bg-transparent" href="#">Next</a></li>
            </ul>
        </nav>
    </div>
</div>

<div class="modal fade" id="modalHapus" tabindex="-1" aria-labelledby="modalHapusLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" style="max-width: 400px;">
        <div class="modal-content border-0 shadow-lg rounded-4">
            <div class="modal-body p-4 text-center">
                <div class="mb-3">
                    <div class="bg-danger bg-opacity-10 text-danger rounded-circle d-inline-flex align-items-center justify-content-center" style="width: 80px; height: 80px;">
                        <i class="bi bi-exclamation-triangle-fill" style="font-size: 2.5rem;"></i>
                    </div>
                </div>
                <h5 class="fw-bold text-dark">Hapus Maintenance?</h5>
                <p class="text-muted small mb-4">
                    Data maintenance yang dihapus tidak dapat dikembalikan. Lanjutkan proses penghapusan?
                </p>
                <div class="d-flex gap-2 justify-content-center">
                    <button type="button" class="btn btn-light border fw-semibold px-4" data-bs-dismiss="modal">Batal</button>
                    <a href="#" id="btnConfirmDelete" class="btn btn-danger fw-semibold px-4">Ya, Hapus</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var modalHapus = document.getElementById('modalHapus');
        
        modalHapus.addEventListener('show.bs.modal', function (event) {
            // Ambil tombol yang diklik
            var button = event.relatedTarget;
            // Ambil ID dari data-id
            var idData = button.getAttribute('data-id');
            
            // Atur Link Hapus
            // Ganti URL dibawah sesuai dengan format link hapus PHP Anda
            var linkHapus = modalHapus.querySelector('#btnConfirmDelete');
            linkHapus.href = '?pg=baru&fl=hapus&id=' + idData;
        });
    });
</script>