<div class="card border-0 shadow-sm rounded-3 overflow-hidden">
    
    <div class="p-4 border-bottom bg-white">
        <h6 class="fw-bold mb-0">Input Maintenance Baru</h6>
        <small class="text-muted">Masukkan data aset yang akan diperbaiki atau diservice.</small>
    </div>

    <div class="card-body p-4">
        <form action="" method="POST">
            
            <div class="p-3 bg-light rounded-3 border border-light mb-4">
                <label class="form-label small fw-bold text-primary text-uppercase mb-3"><i class="bi bi-box-seam me-1"></i> Informasi Aset</label>
                <div class="row g-3">
                    <div class="col-md-8">
                        <label class="form-label small fw-bold text-secondary">Pilih Aset</label>
                        <select class="form-select shadow-none border">
                            <option selected disabled>-- Cari Kode / Nama Aset --</option>
                            <option value="1">Laptop Dell XPS (DL-IT-099)</option>
                            <option value="2">Mobil Operasional (B 1234 CD)</option>
                            <option value="3">AC Ruang Meeting (AC-GA-01)</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label small fw-bold text-secondary">Kondisi Saat Ini</label>
                        <input type="text" class="form-control bg-white text-muted shadow-none" value="Rusak Ringan" readonly>
                    </div>
                </div>
            </div>

            <div class="row g-3 mb-4">
                <div class="col-md-4">
                    <label class="form-label small fw-bold text-secondary text-uppercase">Jenis Kegiatan</label>
                    <select class="form-select form-select-sm border rounded-2 shadow-none">
                        <option value="Perbaikan" selected>Perbaikan Kerusakan</option>
                        <option value="Service Rutin">Service Berkala / Rutin</option>
                        <option value="Pajak">Perpanjangan Pajak / STNK</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold text-secondary text-uppercase">Tanggal Mulai</label>
                    <input type="date" class="form-control form-control-sm border rounded-2 shadow-none" value="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="col-md-4">
                    <label class="form-label small fw-bold text-secondary text-uppercase">Estimasi Biaya (Rp)</label>
                    <div class="input-group input-group-sm">
                        <span class="input-group-text bg-light border-end-0 text-muted">Rp</span>
                        <input type="number" class="form-control border-start-0 shadow-none" placeholder="0">
                    </div>
                </div>

                <div class="col-md-6">
                    <label class="form-label small fw-bold text-secondary text-uppercase">Vendor / Bengkel Pelaksana</label>
                    <input type="text" class="form-control form-control-sm border rounded-2 shadow-none" placeholder="Contoh: CV. Tekno Mandiri">
                </div>
                <div class="col-md-6">
                    <label class="form-label small fw-bold text-secondary text-uppercase">Penanggung Jawab (Internal)</label>
                    <select class="form-select form-select-sm border rounded-2 shadow-none">
                        <option selected>Admin (Saya Sendiri)</option>
                        <option value="1">Budi (Staff GA)</option>
                    </select>
                </div>

                <div class="col-12">
                    <label class="form-label small fw-bold text-secondary text-uppercase">Keluhan / Deskripsi Masalah</label>
                    <textarea class="form-control form-control-sm border rounded-2 shadow-none" rows="3" placeholder="Jelaskan kerusakan atau detail pekerjaan yang harus dilakukan..."></textarea>
                </div>
            </div>

            <div class="p-3 border-top d-flex justify-content-end gap-2 bg-light rounded-bottom-3 mt-4 mx-n4 mb-n4">
                <a href="?pg=baru&fl=list" class="btn btn-light border bg-white text-secondary btn-sm px-4 fw-bold">Batal</a>
                <a href="?pg=baru&fl=list" class="btn btn-primary btn-sm px-4 fw-bold shadow-sm">
                    <i class="bi bi-save me-1"></i> Simpan Jadwal
                </a>
            </div>
        </form>
    </div>
</div>