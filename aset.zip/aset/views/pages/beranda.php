    <?php include('beranda/judul.php') ?>

    <?php include('beranda/statistik.php') ?>

    <?php include('beranda/persentase.php') ?>

    <?php include('beranda/transaksi.php') ?>