<div class="card border-0 shadow-sm rounded-3 overflow-hidden">
    
    <div class="p-4 border-bottom bg-white d-flex justify-content-between align-items-center">
        <div>
            <h6 class="fw-bold mb-0">Edit Data Peminjaman</h6>
            <small class="text-muted">Perbarui informasi peminjaman aktif.</small>
        </div>
        <div class="d-flex align-items-center gap-2">
            <span class="badge bg-warning text-dark border border-warning border-opacity-25 px-3">
                Status: Dipinjam
            </span>
            <span class="badge bg-secondary bg-opacity-10 text-dark border px-3">
                ID: PJ-2310-001
            </span>
        </div>
    </div>

    <div class="card-body p-4">
        
        <div class="alert alert-primary bg-primary bg-opacity-10 border-primary border-opacity-10 d-flex align-items-center p-3 mb-4 rounded-3">
            <i class="bi bi-info-circle-fill text-primary me-3 fs-5"></i>
            <div class="small text-secondary">
                <strong>Catatan Sistem:</strong> Data Peminjam dan Tanggal Awal tidak dapat diubah karena barang sudah keluar. Gunakan form ini untuk <u>memperpanjang durasi</u> atau merubah catatan.
            </div>
        </div>

        <form action="" method="POST">
            <div class="row g-4 mb-4">
                <div class="col-md-6">
                    <div class="p-3 bg-light rounded-3 border border-light h-100">
                        <label class="form-label small fw-bold text-muted text-uppercase mb-3">Informasi Tetap</label>
                        
                        <div class="mb-3">
                            <label class="form-label small text-secondary">Nama Peminjam</label>
                            <input type="text" class="form-control form-control-sm shadow-none bg-white text-dark fw-bold" value="Doni Nugraha (Marketing)" disabled readonly>
                        </div>
                        
                        <div class="mb-0">
                            <label class="form-label small text-secondary">Tanggal Pinjam (Mulai)</label>
                            <input type="date" class="form-control form-control-sm shadow-none bg-white text-dark fw-bold" value="2023-10-10" disabled readonly>
                        </div>
                    </div>
                </div>

                <div class="col-md-6">
                    <div class="p-3 bg-white rounded-3 border h-100">
                        <label class="form-label small fw-bold text-primary text-uppercase mb-3">Informasi Yang Diubah</label>
                        
                        <div class="mb-3">
                            <label class="form-label small fw-bold text-dark">Estimasi Tanggal Kembali (Target)</label>
                            <div class="input-group input-group-sm">
                                <span class="input-group-text bg-white text-primary border-end-0"><i class="bi bi-calendar-check"></i></span>
                                <input type="date" class="form-control shadow-none border-start-0 fw-bold text-primary" value="2023-10-12">
                            </div>
                            <div class="form-text small text-muted fst-italic">Ubah tanggal ini jika ada perpanjangan waktu.</div>
                        </div>

                        <div class="mb-0">
                            <label class="form-label small fw-bold text-dark">Keperluan / Keterangan</label>
                            <textarea class="form-control form-control-sm shadow-none" rows="3">Meeting Luar Kota ke Surabaya untuk presentasi Client.</textarea>
                        </div>
                    </div>
                </div>
            </div>

            <div class="mb-4">
                <div class="d-flex justify-content-between align-items-end mb-2">
                    <label class="form-label small fw-bold text-secondary text-uppercase mb-0">Barang Yang Sedang Dipinjam</label>
                    </div>

                <div class="table-responsive border rounded-3">
                    <table class="table table-premium mb-0 align-middle">
                        <thead class="bg-light">
                            <tr>
                                <th class="ps-4 py-2 text-secondary small text-uppercase">Kode</th>
                                <th class="py-2 text-secondary small text-uppercase">Nama Aset</th>
                                <th class="py-2 text-secondary small text-uppercase">Kondisi Awal</th>
                                <th class="text-end pe-4 py-2 text-secondary small text-uppercase">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td class="ps-4"><span class="badge bg-light text-dark border font-monospace">LP-IT-001</span></td>
                                <td>
                                    <span class="fw-bold text-dark d-block">Laptop Lenovo Thinkpad</span>
                                </td>
                                <td><span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-10">Baik</span></td>
                                <td class="text-end pe-4">
                                    <button type="button" class="btn btn-sm text-danger bg-white border border-danger border-opacity-10 rounded-2" onclick="return confirm('Yakin hapus item ini dari daftar pinjam?');">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                            <tr>
                                <td class="ps-4"><span class="badge bg-light text-dark border font-monospace">PR-GA-005</span></td>
                                <td>
                                    <span class="fw-bold text-dark d-block">Proyektor Epson</span>
                                </td>
                                <td><span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-10">Baik</span></td>
                                <td class="text-end pe-4">
                                    <button type="button" class="btn btn-sm text-danger bg-white border border-danger border-opacity-10 rounded-2">
                                        <i class="bi bi-trash"></i>
                                    </button>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="d-flex justify-content-between align-items-center pt-3 border-top">
                <a href="?pg=kpinjam&fl=list" class="btn btn-link text-decoration-none text-danger btn-sm ps-0 fw-bold">
                    <i class="bi bi-x-circle me-1"></i> Batalkan Transaksi Ini
                </a>
                <div class="d-flex gap-2">
                    <a href="?pg=kpinjam&fl=list" class="btn btn-light border bg-white text-secondary btn-sm px-4 fw-bold">Kembali</a>
                    <a href="?pg=kpinjam&fl=list" class="btn btn-primary btn-sm px-4 fw-bold shadow-sm">
                        <i class="bi bi-save me-1"></i> Simpan Perubahan
                    </a>
                </div>
            </div>
        </form>
    </div>
</div>