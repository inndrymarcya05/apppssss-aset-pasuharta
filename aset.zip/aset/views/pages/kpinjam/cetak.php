<style>
    @media print {
        body * { visibility: hidden; }
        body, html { margin: 0; padding: 0; background-color: white !important; }
        .card, .card * { visibility: visible; }
        .card {
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            margin: 0 !important;
            padding: 0 !important;
            border: none !important;
            box-shadow: none !important;
            max-width: none !important;
        }
        .no-print { display: none !important; }
    }
</style>

<div class="container-fluid py-4">
    
    <div class="d-flex justify-content-between align-items-center mb-4 no-print">
        <a href="?pg=kpinjam&fl=list" class="btn btn-light border bg-white text-secondary shadow-sm">
            <i class="bi bi-arrow-left me-1"></i> Kembali
        </a>
        <a href="?pg=kpinjam&fl=cetak" onclick="window.print()" class="btn btn-primary shadow-sm px-4">
            <i class="bi bi-printer-fill me-1"></i> Cetak Formulir
        </a>
    </div>

    <div class="card border-0 shadow rounded-3 overflow-hidden mx-auto" style="max-width: 210mm; min-height: 297mm;"> 
        <div class="card-body p-5">
            
            <div class="border-bottom pb-4 mb-4 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-3">
                    <div class="bg-primary text-white rounded-3 d-flex align-items-center justify-content-center fw-bold fs-4" style="width: 60px; height: 60px;">
                        <i class="bi bi-buildings"></i>
                    </div>
                    <div>
                        <h5 class="fw-bold mb-0 text-dark">PT. MAJU MUNDUR JAYA</h5>
                        <p class="small text-muted mb-0">Jl. Teknologi No. 12, Jakarta Selatan</p>
                        <p class="small text-muted mb-0">Divisi General Affair & Inventory</p>
                    </div>
                </div>
                <div class="text-end">
                    <h4 class="fw-bold text-uppercase mb-1" style="letter-spacing: 1px;">Form Peminjaman</h4>
                    <span class="badge bg-warning bg-opacity-10 text-dark border border-warning border-opacity-25 px-3 py-2 fs-6">
                        No: PJ/2023/X/102
                    </span>
                </div>
            </div>

            <div class="text-center mb-4">
                <h5 class="fw-bold text-uppercase text-decoration-underline mb-2">Bukti Peminjaman Aset Kantor</h5>
                <p class="text-muted small">
                    Dokumen ini adalah bukti sah peminjaman inventaris perusahaan.
                </p>
            </div>

            <div class="alert alert-light border border-secondary border-opacity-25 d-flex justify-content-center gap-5 mb-4 py-3">
                <div class="text-center">
                    <small class="text-muted text-uppercase fw-bold" style="font-size: 0.7rem;">Tanggal Pinjam</small>
                    <h6 class="fw-bold mb-0 text-primary">10 Oktober 2023</h6>
                </div>
                <div class="border-start border-secondary border-opacity-25"></div>
                <div class="text-center">
                    <small class="text-muted text-uppercase fw-bold" style="font-size: 0.7rem;">Estimasi Kembali</small>
                    <h6 class="fw-bold mb-0 text-danger">12 Oktober 2023</h6>
                </div>
            </div>

            <div class="row g-4 mb-4">
                <div class="col-6">
                    <div class="p-3 bg-light rounded-3 border border-light h-100">
                        <h6 class="fw-bold small text-uppercase text-primary mb-3 border-bottom pb-2">Pemberi Izin (Admin)</h6>
                        <table class="table table-borderless table-sm mb-0 small">
                            <tr>
                                <td class="text-muted" width="80">Nama</td>
                                <td class="fw-bold text-dark">: Budi Santoso</td>
                            </tr>
                            <tr>
                                <td class="text-muted">Jabatan</td>
                                <td class="text-dark">: Staff GA/Inventory</td>
                            </tr>
                        </table>
                    </div>
                </div>
                <div class="col-6">
                    <div class="p-3 bg-light rounded-3 border border-light h-100">
                        <h6 class="fw-bold small text-uppercase text-primary mb-3 border-bottom pb-2">Peminjam Aset</h6>
                        <table class="table table-borderless table-sm mb-0 small">
                            <tr>
                                <td class="text-muted" width="80">Nama</td>
                                <td class="fw-bold text-dark">: Doni Nugraha</td>
                            </tr>
                            <tr>
                                <td class="text-muted">Divisi</td>
                                <td class="text-dark">: Marketing</td>
                            </tr>
                            <tr>
                                <td class="text-muted">Keperluan</td>
                                <td class="text-dark fw-bold">: Meeting Luar Kota</td>
                            </tr>
                        </table>
                    </div>
                </div>
            </div>

            <p class="small text-muted mb-3">
                Rincian barang/aset yang dipinjam adalah sebagai berikut:
            </p>

            <div class="table-responsive mb-4">
                <table class="table table-bordered align-middle border-secondary border-opacity-25">
                    <thead class="bg-light text-center">
                        <tr>
                            <th class="py-2 text-uppercase small fw-bold text-secondary" style="width: 5%;">No</th>
                            <th class="py-2 text-uppercase small fw-bold text-secondary">Kode Aset</th>
                            <th class="py-2 text-uppercase small fw-bold text-secondary" style="width: 40%;">Nama Barang</th>
                            <th class="py-2 text-uppercase small fw-bold text-secondary">Kondisi Awal</th>
                            <th class="py-2 text-uppercase small fw-bold text-secondary">Jumlah</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="text-center small">1</td>
                            <td class="text-center"><span class="small fw-bold font-monospace">LP-IT-001</span></td>
                            <td>
                                <span class="fw-bold d-block text-dark">Laptop Lenovo Thinkpad X1</span>
                                <span class="small text-muted">Kelengkapan: Charger & Tas</span>
                            </td>
                            <td class="text-center"><span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-10 rounded-pill px-2">Baik</span></td>
                            <td class="text-center fw-bold">1 Unit</td>
                        </tr>
                        <tr>
                            <td class="text-center small">2</td>
                            <td class="text-center"><span class="small fw-bold font-monospace">PR-GA-005</span></td>
                            <td>
                                <span class="fw-bold d-block text-dark">Proyektor Epson</span>
                                <span class="small text-muted">Kelengkapan: Kabel HDMI & Power</span>
                            </td>
                            <td class="text-center"><span class="badge bg-success bg-opacity-10 text-success border border-success border-opacity-10 rounded-pill px-2">Baik</span></td>
                            <td class="text-center fw-bold">1 Unit</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            <div class="mb-5 p-3 bg-light border border-secondary border-opacity-10 rounded-3">
                <h6 class="fw-bold small text-uppercase mb-2">Pernyataan Tanggung Jawab:</h6>
                <ol class="small text-muted text-justify mb-0 ps-3" style="line-height: 1.6;">
                    <li>Peminjam menyatakan telah menerima barang tersebut dalam kondisi baik dan lengkap.</li>
                    <li>Peminjam berkewajiban menjaga barang inventaris agar tidak rusak atau hilang selama masa peminjaman.</li>
                    <li>Apabila terjadi kerusakan atau kehilangan akibat kelalaian, Peminjam bersedia bertanggung jawab sesuai kebijakan perusahaan.</li>
                    <li>Barang wajib dikembalikan sesuai dengan tanggal estimasi yang tertulis di atas.</li>
                </ol>
            </div>

            <div class="row mt-5 pt-4">
                <div class="col-6 text-center">
                    <p class="small text-muted mb-1">Jakarta, <?php echo date('d F Y'); ?></p>
                    <p class="fw-bold small">Petugas / Admin,</p>
                    <br><br><br>
                    <p class="fw-bold text-decoration-underline mb-0">Budi Santoso</p>
                    <p class="small text-muted">Inventory Staff</p>
                </div>
                <div class="col-6 text-center">
                    <p class="small text-muted mb-1">Mengetahui & Menyetujui,</p>
                    <p class="fw-bold small">Peminjam,</p>
                    <br><br><br>
                    <p class="fw-bold text-decoration-underline mb-0">Doni Nugraha</p>
                    <p class="small text-muted">Marketing Dept.</p>
                </div>
            </div>

        </div>
    </div>
</div>