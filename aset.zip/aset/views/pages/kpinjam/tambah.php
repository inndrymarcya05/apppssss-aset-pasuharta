<div class="card border-0 shadow-sm rounded-3 overflow-hidden">
    <div class="p-4 border-bottom bg-white">
        <h6 class="fw-bold mb-0">Form Peminjaman Baru</h6>
        <small class="text-muted">Isi data peminjaman dan estimasi pengembalian.</small>
    </div>

    <div class="card-body p-4">
        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <label class="form-label small fw-bold text-secondary text-uppercase">Nama Peminjam</label>
                <select class="form-select form-select-sm border rounded-2 shadow-none">
                    <option selected disabled>-- Pilih Pegawai --</option>
                    <option value="1">Doni Nugraha (Marketing)</option>
                    <option value="2">Budi (IT)</option>
                </select>
            </div>
            <div class="col-md-4">
                <label class="form-label small fw-bold text-secondary text-uppercase">Tanggal Pinjam</label>
                <input type="date" class="form-control form-control-sm border rounded-2 shadow-none" value="<?php echo date('Y-m-d'); ?>">
            </div>
            <div class="col-md-4">
                <label class="form-label small fw-bold text-danger text-uppercase">Estimasi Kembali</label>
                <input type="date" class="form-control form-control-sm border rounded-2 shadow-none border-danger border-opacity-25 bg-danger bg-opacity-10 text-danger fw-bold">
            </div>
            <div class="col-12">
                <label class="form-label small fw-bold text-secondary text-uppercase">Keperluan</label>
                <textarea class="form-control form-control-sm border rounded-2 shadow-none" rows="2" placeholder="Contoh: Meeting Luar Kota, Presentasi Client, dll..."></textarea>
            </div>
        </div>

        <hr class="border-secondary opacity-10 my-4">

        <div class="d-flex flex-wrap align-items-end gap-3 mb-3 p-3 bg-light rounded-3 border border-light">
            <div class="flex-grow-1">
                <label class="form-label small fw-bold text-dark">Pilih Aset</label>
                <select class="form-select border shadow-none">
                    <option selected disabled>-- Cari Barang (Laptop, Proyektor, Kendaraan) --</option>
                    <option value="LP01">Laptop Lenovo (LP-IT-001) - Kondisi: Baik</option>
                    <option value="PR05">Proyektor Epson (PR-GA-005) - Kondisi: Baik</option>
                </select>
            </div>
            <button type="button" class="btn btn-primary px-4"> <i class="bi bi-plus-lg me-1"></i> Tambah</button>
        </div>

        <div class="table-responsive border rounded-3 mb-4">
            <table class="table table-premium mb-0 align-middle">
                <thead class="bg-light">
                    <tr>
                        <th class="ps-4 py-2 text-secondary small">No</th>
                        <th class="py-2 text-secondary small">Kode</th>
                        <th class="py-2 text-secondary small">Nama Aset</th>
                        <th class="text-end pe-4 py-2 text-secondary small">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="ps-4 small">1</td>
                        <td><span class="badge bg-light text-dark border">LP-IT-001</span></td>
                        <td class="fw-bold text-dark">Laptop Lenovo Thinkpad</td>
                        <td class="text-end pe-4">
                            <button class="btn btn-sm text-danger bg-white border border-danger border-opacity-10 rounded-2"><i class="bi bi-trash"></i></button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="p-3 border-top d-flex justify-content-end gap-2 bg-light">
        <a href="?pg=peminjaman" class="btn btn-light border bg-white text-secondary btn-sm px-4 fw-bold">Batal</a>
        <button type="submit" class="btn btn-primary btn-sm px-4 fw-bold shadow-sm"><i class="bi bi-save me-1"></i> Simpan Peminjaman</button>
    </div>
</div>