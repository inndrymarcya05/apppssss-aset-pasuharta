<div class="card border-0 shadow-sm rounded-3 overflow-hidden">
    <div class="p-4 border-bottom bg-success bg-opacity-10 d-flex justify-content-between align-items-center">
        <div>
            <h6 class="fw-bold mb-0 text-success">Formulir Pengembalian Aset</h6>
            <small class="text-muted">Berita Acara Serah Terima (BAST) Kembali</small>
        </div>
        <span class="badge bg-primary text-primary bg-opacity-10 border border-primary border-opacity-25 px-3 py-2">
            Mode: Edit
        </span>
    </div>

    <div class="card-body p-4">
        <div class="alert alert-light border mb-4">
            <div class="row g-3">
                <div class="col-md-3">
                    <label class="form-label small fw-bold text-secondary text-uppercase mb-1">No. Surat BAST</label>
                    <input type="text" class="form-control form-control-sm fw-bold font-monospace text-dark" value="BAST-K/23/10/099">
                </div>
                
                <div class="col-md-3">
                    <label class="form-label small fw-bold text-secondary text-uppercase mb-1">Tgl Serah Terima</label>
                    <input type="date" class="form-control form-control-sm fw-bold text-success" value="<?php echo date('Y-m-d'); ?>">
                </div>

                <div class="col-md-3">
                    <label class="form-label small fw-bold text-secondary text-uppercase mb-1">Penerima (Admin)</label>
                    <select class="form-select form-select-sm fw-bold text-dark">
                        <option value="1" selected>Budi Santoso (AS)</option>
                        <option value="2">Siti Aminah (AI)</option>
                        <option value="3">Rudi Hermawan (T)</option>
                        <option value="4">Rudi (S)</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label class="form-label small fw-bold text-secondary text-uppercase mb-1">Peminjam (User)</label>
                    <div class="input-group input-group-sm">
                        <input type="text" class="form-control fw-bold text-dark" value="Doni Nugraha" placeholder="Cari Pegawai...">
                        <button class="btn btn-outline-secondary" type="button"><i class="bi bi-search"></i></button>
                    </div>
                </div>
            </div>
        </div>

        <h6 class="fw-bold small text-secondary mb-3 text-uppercase d-flex justify-content-between align-items-center">
            <span>Daftar Item Aset Pengembalian</span>
            <button class="btn btn-sm btn-outline-success border-0 fw-bold">
                <i class="bi bi-plus-circle me-1"></i> Tambah Item
            </button>
        </h6>
        
        <div class="table-responsive border rounded-3 mb-4">
            <table class="table table-hover mb-0 align-middle">
                <thead class="bg-light">
                    <tr>
                        <th class="ps-4 py-3 text-secondary small text-uppercase">Detail Aset</th>
                        <th class="py-3 text-secondary small text-uppercase">Kondisi Awal</th>
                        <th class="py-3 text-secondary small text-uppercase" style="width: 200px;">Kondisi Akhir</th>
                        <th class="py-3 text-secondary small text-uppercase text-center" style="width: 100px;">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td class="ps-4">
                            <div class="d-flex align-items-center">
                                <div class="bg-light rounded p-2 me-3 border">
                                    <i class="bi bi-laptop fs-5 text-secondary"></i>
                                </div>
                                <div>
                                    <span class="d-block fw-bold text-dark">Laptop Lenovo Thinkpad</span>
                                    <small class="text-muted font-monospace">ID: LP-IT-001</small>
                                </div>
                            </div>
                        </td>
                        <td><span class="badge bg-success bg-opacity-10 text-success rounded-pill">Baik</span></td>
                        <td>
                            <select class="form-select form-select-sm border shadow-none bg-light">
                                <option value="Baik" selected>Baik</option>
                                <option value="Rusak Ringan">Rusak Ringan</option>
                                <option value="Rusak Berat">Rusak Berat</option>
                            </select>
                        </td>
                        <td class="text-center">
                            <button class="btn btn-outline-danger btn-sm border-0" onclick="return confirm('Hapus item ini dari daftar pengembalian?')" title="Hapus Item">
                                <i class="bi bi-trash fs-6"></i>
                            </button>
                        </td>
                    </tr>

                    <tr>
                        <td class="ps-4">
                            <div class="d-flex align-items-center">
                                <div class="bg-light rounded p-2 me-3 border">
                                    <i class="bi bi-mouse fs-5 text-secondary"></i>
                                </div>
                                <div>
                                    <span class="d-block fw-bold text-dark">Mouse Logitech Wireless</span>
                                    <small class="text-muted font-monospace">ID: MS-IT-022</small>
                                </div>
                            </div>
                        </td>
                        <td><span class="badge bg-success bg-opacity-10 text-success rounded-pill">Baik</span></td>
                        <td>
                            <select class="form-select form-select-sm border shadow-none bg-light">
                                <option value="Baik" selected>Baik</option>
                                <option value="Rusak">Rusak</option>
                                <option value="Hilang">Hilang</option>
                            </select>
                        </td>
                        <td class="text-center">
                            <button class="btn btn-outline-danger btn-sm border-0" onclick="return confirm('Hapus item ini dari daftar pengembalian?')" title="Hapus Item">
                                <i class="bi bi-trash fs-6"></i>
                            </button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <div class="mb-3">
            <label class="form-label small fw-bold text-secondary">Catatan Kondisi Akhir</label>
            <textarea class="form-control border shadow-none bg-light" rows="2" placeholder="Tulis catatan..."></textarea>
        </div>
    </div>
        <div class="d-flex gap-2">
            <a href="?pg=kpinjam&fl=list" class="btn btn-light border bg-white text-secondary btn-sm px-4 fw-bold">Batal</a>
            <a href="?pg=kpinjam&fl=list" type="submit" class="btn btn-success btn-sm px-4 fw-bold shadow-sm">
                <i class="bi bi-save me-1"></i> Simpan Perubahan
            </a>
        </div>
    </div>
</div>