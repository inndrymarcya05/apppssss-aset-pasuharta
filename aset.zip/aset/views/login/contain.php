<div class="col-lg-6 login-image">
            <h1 class="display-4 fw-bold mb-4">Pencatatan Asset Secara Digital.</h1>
            <p class="lead mb-4" style="opacity: 0.9;">Kelola Asset Anda dengan sistem dashboard tercanggih dan analitik yang presisi.</p>
            <div class="d-flex align-items-center gap-3">
                <div class="avatar-group d-flex">
                    <span class="badge rounded-pill bg-light text-dark p-2 px-3 shadow-sm">
                        <i class="bi bi-star-fill text-warning me-1"></i> 
                        Terpercaya oleh 1,000,000,000+ pengguna
                    </span>
                </div>
            </div>
        </div>