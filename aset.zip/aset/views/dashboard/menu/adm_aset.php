
<div class="nav-section-label">Admin Aset</div>
<a href="?pg=kaset&fl=list" class="nav-link-custom <?= $ac['kaset'] ?>"><i data-lucide="package"></i> Kelola aset</a>
<a href="?pg=kategori&fl=list" class="nav-link-custom <?= $ac['kategori'] ?>"><i data-lucide="box"></i> Kategori</a>
<a href="?pg=lokasi&fl=list" class="nav-link-custom <?= $ac['lokasi'] ?>"><i data-lucide="map-pin"></i> Lokasi</a>
<a href="?pg=Kserah&fl=list" class="nav-link-custom <?= $ac['Kserah'] ?>"><i data-lucide="handshake"></i> Serah terima aset</a>
<a href="?pg=khapus&fl=list" class="nav-link-custom <?= $ac['khapus'] ?>"><i data-lucide="file-x-corner"></i> Penghapusan</a>

