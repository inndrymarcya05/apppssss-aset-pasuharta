    
<div class="nav-section-label">Admin Instansi</div>
    <a href="?pg=kpegawai&fl=list" class="nav-link-custom <?= $ac['kpegawai'] ?>"><i data-lucide="user"></i> Pegawai</a>
    <a href="?pg=kpengelola&fl=list" class="nav-link-custom <?= $ac['kpengelola'] ?>"><i data-lucide="userCog"></i> Pengelola aset</a>