
<div class="nav-section-label">Teknisi Aset</div>
<a href="?pg=baru&fl=list" class="nav-link-custom <?= $ac['baru'] ?>"><i data-lucide="Wrench"></i>  Perbaikan</a>