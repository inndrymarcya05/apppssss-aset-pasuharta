
<div class="nav-section-label">Staf Aset</div>
<a href="?pg=kpinjam&fl=list" class="nav-link-custom <?= $ac['kpinjam'] ?>"><i data-lucide="ClipboardList"></i> Peminjaman aset</a>